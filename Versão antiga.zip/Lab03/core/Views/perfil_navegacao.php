<div class="container-fluid">
    <div class="row my-3">
        <div class="col text-center">
            <a href="?a=alterar_dados_pessoais" class="btn btn-primary m-1"><i class="fas fa-edit"></i> Alterar dados pessoais</a>
            <a href="?a=alterar_password" class="btn btn-primary m-1"><i class="fas fa-key"></i> Alterar a password</a>
            <a href="?a=historico_encomendas" class="btn btn-primary m-1"><i class="far fa-list-alt"></i> Histórico de encomendas</a>
        </div>
    </div>
</div>