<div class="container-fluid fixed-bottom rodape">
    <div class="row">
        <div class="col-12 text-center p-3">
            <small><?= APP_NAME .'('.APP_VERSION.') &copy; ' . date('Y')?></small>
        </div>
    </div>
</div>