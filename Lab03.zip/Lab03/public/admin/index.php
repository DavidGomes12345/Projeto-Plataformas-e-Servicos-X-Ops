<?php

// abrir a sessao
session_start();

// carrega todas as classes do projeto
require_once('../../vendor/autoload.php');

// carrega o sistema de rotas
require_once('../../core/rotas_admin.php');